function [im2] = color_global_tSVD_read_patch(im1,ps,SR,sigma,maxK,N_step,modified,tau,GPU_choose)
%color_t_hosvd_denoising Summary of this function goes here
%   Detailed explanation goes here
[H,W,D] = size(im1);
load U;load V;
info1 = [H,W,D];
info2 = [ps,N_step,SR,maxK];
info3 = [1.1,sigma,1];
if(GPU_choose == 1)
    [similar_indice] = GPU_search(single(im1),int32(info1),int32(info2), single(info3));
else
    [similar_indice] = CPU_search(single(im1),int32(info1),int32(info2), single(info3));
end
im2 = color_denoising_global_tSVD(single(im1),int32(similar_indice),single(U),single(V),int32(info1),int32(info2), single(info3));im2 = mat_ten(im2,1,size(im1));
end
